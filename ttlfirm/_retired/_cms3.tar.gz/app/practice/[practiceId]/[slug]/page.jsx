// ===========================================
// app/practice/[practiceId]/[subService]/page.jsx - FINAL VERSION
// Uses TailoredCTA component (WhyChooseUs design)
// ===========================================
import { client } from "@/lib/sanity.client";
import {
  subServiceBySlugQuery,
  practiceAreasQuery,
} from "@/lib/sanity.queries";
import { urlFor } from "@/lib/sanity.client";
import { PortableText } from "@portabletext/react";
import PortableTextComponents from "@/components/blog/PortableTextComponents";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import Accordion from "@/components/uiComponents/accordion";
import { FaArrowRightLong } from "react-icons/fa6";
import SEOHead from "@/components/SEOHead";
import { generateLocalBusinessSchema } from "@/lib/seo";
import TailoredCTA from "@/components/common/TailoredCTA"; // NEW
import { filterRetiredAreas, RETIRED_PRACTICE_SLUGS } from "@/lib/siteNav";

export const revalidate = 60;

// Generate static paths
// NOTE: this route lives at app/practice/[practiceId]/[slug]/page.jsx, so
// Next.js only ever gives us params.slug — a param named `subService` here
// was silently ignored, and every page below fell back to `undefined`,
// which meant the Sanity query always came back empty and the page 404'd
// regardless of what's published in the CMS.
export async function generateStaticParams() {
  const practiceAreas = await client.fetch(practiceAreasQuery);

  const paths = [];
  for (const area of practiceAreas) {
    if (area.subServices) {
      for (const service of area.subServices) {
        paths.push({
          practiceId: area.slug.current,
          slug: service.slug.current,
        });
      }
    }
  }

  return paths;
}

// Generate metadata
export async function generateMetadata({ params }) {
  const { slug: subServiceSlug } = await params;
  const subService = await client.fetch(subServiceBySlugQuery, {
    slug: subServiceSlug,
  });

  if (!subService) {
    return { title: "Service Not Found" };
  }

  return {
    title:
      subService.seo?.metaTitle ||
      `${subService.title} | ${subService.practiceArea?.name} | Turuchi Law Firm`,
    description: subService.seo?.metaDescription || subService.excerpt,
    keywords: subService.seo?.keywords?.join(", "),
    openGraph: {
      title: subService.seo?.metaTitle || subService.title,
      description: subService.seo?.metaDescription || subService.excerpt,
      images: subService.seo?.ogImage
        ? [urlFor(subService.seo.ogImage).width(1200).height(630).url()]
        : subService.image
          ? [urlFor(subService.image).width(1200).height(630).url()]
          : [],
    },
  };
}

async function getSubService(slug) {
  const subService = await client.fetch(subServiceBySlugQuery, { slug });
  return subService;
}

async function getPracticeAreas() {
  const areas = await client.fetch(practiceAreasQuery);
  return areas;
}

export default async function SubServicePage({ params }) {
  const { slug: subServiceSlug, practiceId } = await params;

  // Sub-services under a retired practice area must 404 too.
  if (RETIRED_PRACTICE_SLUGS.includes(practiceId)) {
    notFound();
  }

  const [subService, practiceAreas] = await Promise.all([
    getSubService(subServiceSlug),
    getPracticeAreas(),
  ]);

  if (!subService) {
    notFound();
  }

  // Generate structured data schema for SEO
  const schema = generateLocalBusinessSchema(
    subService,
    subService.counties?.[0]
  );

  // Convert FAQs to accordion format
  const accordionData =
    subService.faqs?.map((faq) => ({
      title: faq.question,
      content: (
        <PortableText value={faq.answer} components={PortableTextComponents} />
      ),
    })) || [];

  return (
    <>
      {/* SEO Schema Markup */}
      <SEOHead schema={schema} />

      <div className="w-full flex flex-col">
        {/* Header */}
        <div className="relative w-full h-[400px] bg-gradient-to-r from-gray-900 to-gray-800">
          {subService.image && (
            <Image
              src={urlFor(subService.image).width(1920).height(600).url()}
              alt={subService.image.alt || subService.title}
              fill
              className="object-cover opacity-40"
            />
          )}
          <div className="absolute inset-0 flex flex-col justify-center items-center text-white z-10">
            {/* Breadcrumbs */}
            <nav className="flex gap-2 text-sm mb-4">
              <Link href="/" className="hover:text-accent-500">
                Home
              </Link>
              <span>/</span>
              <Link href="/practice" className="hover:text-accent-500">
                Practice Areas
              </Link>
              <span>/</span>
              <Link
                href={`/practice/${subService.practiceArea?.slug.current}`}
                className="hover:text-accent-500"
              >
                {subService.practiceArea?.name}
              </Link>
              <span>/</span>
              <span>{subService.title}</span>
            </nav>

            <h1 className="font-display text-4xl md:text-5xl font-bold text-center px-4">
              {subService.title}
            </h1>
          </div>
        </div>

        {/* Content */}
        <div className="relative w-full bg-zinc-100 flex flex-col md:flex-row-reverse justify-center items-start md:justify-around md:pl-5 py-12">
          {/* Main Content */}
          <div className="flex flex-col w-full md:w-[70%] p-8 sm:p-16 md:px-12 gap-8">
            {/* Overview */}
            {subService.overview && (
              <div className="prose prose-lg max-w-none">
                <PortableText
                  value={subService.overview}
                  components={PortableTextComponents}
                />
              </div>
            )}

            {/* Process Steps */}
            {subService.process && subService.process.length > 0 && (
              <div>
                <h2 className="font-display text-3xl font-bold mb-6">
                  Our Process
                </h2>
                <div className="space-y-6">
                  {subService.process.map((step, index) => (
                    <div
                      key={index}
                      className="flex gap-4 p-6 bg-white rounded-lg shadow-md"
                    >
                      <div className="flex-shrink-0 w-12 h-12 bg-accent-500 text-white rounded-full flex items-center justify-center font-bold text-xl">
                        {index + 1}
                      </div>
                      <div>
                        <h3 className="font-display text-xl font-semibold mb-2">
                          {step.title}
                        </h3>
                        <p className="text-gray-700">{step.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* County-Specific Content */}
            {subService.countyContent &&
              subService.countyContent.length > 0 && (
                <div className="mt-8">
                  <h2 className="font-display text-3xl font-bold mb-6">
                    County-Specific Information
                  </h2>
                  <div className="space-y-6">
                    {subService.countyContent.map((item, index) => (
                      <div
                        key={index}
                        className="border-l-4 border-accent-500 pl-6"
                      >
                        <h3 className="font-display text-2xl font-semibold mb-4">
                          {item.county.name}
                        </h3>
                        {item.localStats && (
                          <div className="bg-blue-50 p-4 rounded mb-4">
                            <p className="text-sm font-semibold text-blue-900">
                              Local Statistics:
                            </p>
                            <p className="text-gray-700">{item.localStats}</p>
                          </div>
                        )}
                        <div className="prose max-w-none">
                          <PortableText
                            value={item.content}
                            components={PortableTextComponents}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            {/* FAQs */}
            {accordionData.length > 0 && (
              <Accordion
                title="Frequently Asked Questions"
                accordionData={accordionData}
                usePadding={false}
              />
            )}

            {/* Related Services */}
            {subService.relatedServices &&
              subService.relatedServices.length > 0 && (
                <div className="mt-8">
                  <h2 className="font-display text-3xl font-bold mb-6">
                    Related Services
                  </h2>
                  <div className="grid md:grid-cols-2 gap-6">
                    {subService.relatedServices.map((service) => (
                      <Link
                        key={service._id}
                        href={`/practice/${subService.practiceArea?.slug.current}/${service.slug.current}`}
                        className="p-6 bg-white rounded-lg shadow hover:shadow-lg transition group"
                      >
                        <h3 className="font-display text-xl font-semibold mb-2 group-hover:text-accent-500 transition">
                          {service.title}
                        </h3>
                        <p className="text-gray-600 line-clamp-2">
                          {service.excerpt}
                        </p>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
          </div>

          {/* Sidebar */}
          <div className="w-full md:w-[30%] p-8">
            <div className="w-full flex flex-col gap-5 md:sticky md:top-24">
              <h2 className="font-display text-2xl font-medium">Practice Areas</h2>
              {practiceAreas.map((area) => (
                <div className="w-full flex flex-col gap-4" key={area._id}>
                  <hr className="w-full h-[1.5px] bg-accent-500 opacity-20" />
                  <Link
                    href={`/practice/${area.slug.current}`}
                    className="hover:ml-4 hover:text-accent-500 hover:opacity-80 flex flex-row transition-all duration-300 gap-3 items-center font-medium text-base"
                  >
                    <FaArrowRightLong className="text-xs" />
                    <span>{area.name}</span>
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Tailored CTA Section - NEW COMPONENT */}
        <TailoredCTA ctaData={subService.ctaSection} />
      </div>
    </>
  );
}