"use client";
import AmbientVideo from "@components/common/ambientVideo";

/**
 * Hero background.
 *
 * The firm's film is shot PORTRAIT (9:16), and that shapes how it is used at
 * each width:
 *
 *  - Under `lg` the viewport is itself portrait, so the film fills the hero
 *    edge to edge with almost no cropping. It is the background, and it is
 *    the subject.
 *  - At `lg` and up a 9:16 source cropped into a ~2:1 hero can only show a
 *    horizontal band from the middle of the frame — so there the film is NOT
 *    the subject. It runs as an ambient layer: low opacity, softly blurred,
 *    under the same deep scrim, so what reaches the eye is movement and light
 *    rather than a slice of someone's midsection. The film proper is presented
 *    in the framed vertical player beside the copy (filmPlayer.jsx).
 *
 * Swapping in a landscape (16:9) master later is a one-line change: drop the
 * blur and raise the opacity in the desktop `videoClassName` below.
 */
const HeroMedia = ({
  videoSrc = "/assets/videos/hero-loop.mp4",
  posterSrc = "/assets/videos/hero-poster.jpg",
  backdropSrc = "/assets/videos/hero-backdrop.jpg",
  imageSrc,
}) => {
  // An explicit image from the CMS wins — it means the editor chose a still.
  const src = imageSrc ? null : videoSrc;

  return (
    <div className="absolute inset-0 -z-10 overflow-hidden bg-navy-950">
      {/* ---------------------------------------------- mobile / tablet: film */}
      <div className="absolute inset-0 lg:hidden">
        <AmbientVideo src={src} poster={imageSrc || posterSrc} eager />
        <div className="absolute inset-0 hero-scrim-mobile" aria-hidden="true" />
      </div>

      {/* --------------------------------------------- desktop: ambient film */}
      <div className="absolute inset-0 hidden lg:block">
        <AmbientVideo
          src={src}
          poster={imageSrc || backdropSrc}
          eager
          stillClassName="opacity-30"
          videoClassName="scale-110 opacity-[.5] blur-[2px] saturate-[.85]"
        />
        <div className="absolute inset-0 hero-scrim-desktop" aria-hidden="true" />
      </div>

      {/* Bottom fade into the next section. */}
      <div
        className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-navy-950/95 to-transparent"
        aria-hidden="true"
      />
    </div>
  );
};

export default HeroMedia;
