"use client";
import { useEffect, useRef, useState } from "react";

/**
 * A muted, looping video used purely as a background layer.
 *
 * Shared by the homepage hero and the landing page heroes so there is one
 * place that decides when a background video is allowed to play:
 *
 *  - never for `prefers-reduced-motion`
 *  - never on Save Data, or on a connection reporting 2G / slow-2G — ad
 *    traffic is overwhelmingly mobile on cellular, and a background flourish
 *    is not worth a megabyte of someone's data plan
 *  - never before the element is on screen, so a hero further down a landing
 *    page costs nothing until it is reached
 *
 * The still is always rendered underneath. The video fades in over it once it
 * can actually play, which means a slow or failed load degrades to the poster
 * instead of to a black box.
 */
const AmbientVideo = ({
  src,
  poster,
  /** Extra classes for the <video> and the still — usually opacity and filters. */
  videoClassName = "",
  stillClassName = "",
  /** Skip the in-view wait for a hero that is above the fold anyway. */
  eager = false,
}) => {
  const hostRef = useRef(null);
  const videoRef = useRef(null);
  const [allowed, setAllowed] = useState(false);
  const [visible, setVisible] = useState(eager);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!src) return;

    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const connection =
      navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    const saveData = connection?.saveData === true;
    const slowNetwork = ["slow-2g", "2g"].includes(connection?.effectiveType);

    if (reducedMotion || saveData || slowNetwork) return;
    setAllowed(true);
  }, [src]);

  useEffect(() => {
    if (eager || visible) return;
    const el = hostRef.current;
    if (!el || typeof IntersectionObserver === "undefined") {
      setVisible(true);
      return;
    }
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          io.disconnect();
        }
      },
      { rootMargin: "200px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [eager, visible]);

  useEffect(() => {
    if (!allowed || !visible) return;
    const el = videoRef.current;
    if (!el) return;
    // `autoplay muted playsInline` is what actually starts this in almost every
    // browser; the explicit play() is a nudge for the ones that need it after a
    // route change. If it is refused (a low-power-mode iPhone, a strict
    // autoplay policy) keep the still on top rather than unmounting the video —
    // the browser may well start it a moment later on its own, and unmounting
    // would throw away that chance.
    el.play().catch(() => setReady(false));
  }, [allowed, visible]);

  const showVideo = Boolean(src) && allowed && visible;

  return (
    <div ref={hostRef} className="absolute inset-0">
      {poster && (
        <img
          src={poster}
          alt=""
          aria-hidden="true"
          className={`absolute inset-0 h-full w-full object-cover object-center transition-opacity duration-700 ${
            ready ? "opacity-0" : "opacity-100"
          } ${stillClassName}`}
        />
      )}
      {showVideo && (
        <video
          ref={videoRef}
          src={src}
          poster={poster}
          autoPlay
          muted
          loop
          playsInline
          preload="metadata"
          aria-hidden="true"
          tabIndex={-1}
          onCanPlay={() => setReady(true)}
          onPlaying={() => setReady(true)}
          className={`absolute inset-0 h-full w-full object-cover object-center transition-opacity duration-700 ${
            ready ? "opacity-100" : "opacity-0"
          } ${videoClassName}`}
        />
      )}
    </div>
  );
};

export default AmbientVideo;
