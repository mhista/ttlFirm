"use client";
import AmbientVideo from "@components/common/ambientVideo";

/**
 * Hero background.
 *
 * There are two masters, because a phone viewport and a desktop viewport want
 * opposite crops of the same shoot:
 *
 *  - Under `lg` — the PORTRAIT loop (9:16). A phone is itself portrait, so it
 *    fills the hero edge to edge with almost no cropping.
 *  - At `lg` and up — the LANDSCAPE loop (3:2). This is the film she supplied
 *    as a wide export, and it is the subject: full bleed, no blur, no opacity
 *    trick. The scrim over it is deliberately light (see `.hero-scrim-film` in
 *    global.css) so the courthouse and the attorney actually read, which is the
 *    whole point of putting footage behind a hero.
 *
 * `desktopMode` decides what desktop gets:
 *
 *    "video"  the landscape loop (default)
 *    "image"  a wide still — for when the footage on hand isn't the right
 *             shape or resolution for full bleed, while the phone keeps the
 *             portrait loop. Both are editable in the Studio.
 *
 * Everything to do with reduced motion, Save Data and slow connections lives
 * in ambientVideo.jsx, so there is one rule rather than four.
 */
const HeroMedia = ({
  // ------------------------------------------------------ phones / tablets
  videoSrc = "/assets/videos/hero-loop.mp4",
  posterSrc = "/assets/videos/hero-poster.jpg",

  // ------------------------------------------------------------- desktop
  desktopMode = "video",
  desktopVideoSrc = "/assets/videos/hero-loop-wide.mp4",
  desktopPosterSrc = "/assets/videos/hero-poster-wide.jpg",
  desktopImageSrc = "/assets/videos/hero-backdrop-wide.jpg",

  /** A still from the CMS that replaces the background everywhere. */
  imageSrc,
}) => {
  const mobileVideo = imageSrc ? null : videoSrc;
  const desktopVideo = imageSrc || desktopMode === "image" ? null : desktopVideoSrc;
  const desktopStill = imageSrc || (desktopMode === "image" ? desktopImageSrc : desktopPosterSrc);

  return (
    <div className="absolute inset-0 -z-10 overflow-hidden bg-navy-950">
      {/* ---------------------------------------------- phones: portrait loop */}
      <div className="absolute inset-0 lg:hidden">
        <AmbientVideo src={mobileVideo} poster={imageSrc || posterSrc} eager />
        <div className="absolute inset-0 hero-scrim-mobile" aria-hidden="true" />
      </div>

      {/* -------------------------------------------- desktop: landscape loop */}
      <div className="absolute inset-0 hidden lg:block">
        <AmbientVideo
          src={desktopVideo}
          poster={desktopStill}
          eager
          // A still standing in for the video is dimmed a little further than
          // the video is, because a frozen frame draws more attention to its
          // own softness than a moving one does.
          stillClassName={desktopMode === "image" && !imageSrc ? "opacity-90" : ""}
        />
        <div className="absolute inset-0 hero-scrim-film" aria-hidden="true" />
      </div>

      {/* Bottom fade into the next section. */}
      <div
        className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-navy-950/90 to-transparent"
        aria-hidden="true"
      />
    </div>
  );
};

export default HeroMedia;
