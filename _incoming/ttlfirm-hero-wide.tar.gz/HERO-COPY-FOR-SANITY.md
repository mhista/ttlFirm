# Homepage hero — replace the copy in Sanity

The hero on the live site still runs the old paragraph, the one that opens *"Trusted New Jersey
Law firm delivering our absolute best…"* and then lists immigration and municipal court. That copy
lives in the Sanity **Homepage** document, not in the code, so it has to be changed there — the
site cannot override it.

Two problems with it:

1. **It names practice areas the firm no longer runs.** Immigration and municipal court were
   removed from every other surface of the site months of work ago; this is the last place they
   still appear to a visitor.
2. **It is about six times too long for a hero.** Sixty words of body copy over moving footage is
   read by almost nobody. The job of a hero is to say what happened to you and what to do next.

## Where

Sanity Studio → **Homepage** → **Hero** → then **Publish**.

## What to paste

**Eyebrow**

```
New Jersey
```

**Heading**

```
Injured in New Jersey? Don't face the insurer alone.
```

**Description**

```
The other side already has lawyers working its case. We make sure you have one working yours — and you pay nothing unless we recover.
```

**Bullets** (three, short — these are already right if they read like this)

```
Free consultation, no obligation
No fee unless we recover for you
Former insurance defense attorney
```

**Button text**

```
Get Your Free Case Review
```

## About the SEO

Dropping "personal injury and workers' compensation lawyer" out of the H1 costs nothing that
matters. Those terms are still carried by:

- the page `<title>` — *New Jersey Personal Injury & Workers' Compensation Lawyer | The Turuchi Law Firm*
- the meta description
- the H2 on the practice areas section
- the `LegalService` schema in the page's structured data
- every practice area page

Google reads all of those. What the H1 has to do is make a hurt person keep reading.

## If she wants her own words

Two rules, and anything else is fine:

- **Heading: 8 words or fewer.** It sets in three lines on a phone at that length; beyond it, it
  sets in five and pushes the buttons below the fold.
- **Description: two sentences.** One about the problem, one about what the firm does. Detail
  belongs in the sections below, which is exactly what they are for.
